//
// Created by Denisa on 4/13/2022.
//

#ifndef LAB78_SERVICE_H
#define LAB78_SERVICE_H
#include "Repo.h"

class Service {
private:
    Repo repo;
public:
    Service();
    Service(Repo& repo);
    ~Service();

    void addCheltuiala(int day, float sum, char* type);
    void updateCheltuiala(int oldDay, float oldSum, char* oldType, int newDay, float newSum, char* newType);
    void deleteCheltuiala(int day, float sum, char* type);
    Repo getRepo();

};


#endif //LAB78_SERVICE_H
