#include "Service.h"
#include "Cheltuiala.h"

Service::Service() {

}

Service::Service(Repo &repo) {

    this->repo = repo;
}

Service::~Service() {
}

void Service::addCheltuiala(int day, float sum, char *type) {

    Cheltuiala c(day, sum, type);
    this->repo.add(c);
}

void Service::updateCheltuiala(int oldDay, float oldSum, char *oldType, int newDay, float newSum, char *newType) {
    Cheltuiala oldC(oldDay, oldSum, oldType);
    Cheltuiala newC(newDay, newSum, newType);
    this->repo.update(oldC, newC);

}

void Service::deleteCheltuiala(int day, float sum, char *type) {
    Cheltuiala c(day, sum, type);
    this->repo.del(c);

}

Repo Service::getRepo() {
    return this->repo;
}

