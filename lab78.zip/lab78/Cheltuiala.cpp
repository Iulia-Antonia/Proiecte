//
// Created by Denisa on 4/8/2022.
//

#include "Cheltuiala.h"
#include <string.h>


Cheltuiala::Cheltuiala() {
    this->day = 1;
    this->sum = 0;
    this->type = new char[1];
    strcpy_s(this->type, 1, "");
}


Cheltuiala::Cheltuiala(int day, float sum, const char* type) {
    this->day = day;
    this->sum = sum;
    this->type = new char[strlen(type) + 1];
    strcpy_s(this->type, strlen(type) + 1, type);

}

Cheltuiala::Cheltuiala(const Cheltuiala &c) {
    this->day = c.day;
    this->sum = c.sum;
    this->type = new char[strlen(c.type) + 1];
    strcpy_s(this->type, strlen(c.type) + 1, c.type);
}

Cheltuiala::~Cheltuiala() {
    if(this->type)
    {
        delete[] this->type;
        this->type = nullptr;
    }
}

int Cheltuiala::getDay() {
    return this->day;
}

float Cheltuiala::getSum() {
    return this->sum;
}

char* Cheltuiala::getType() {
    return this->type;
}

void Cheltuiala::setDay(int dayValue) {
    this->day = dayValue;
}

void Cheltuiala::setSum(float sumValue) {
    this->sum = sumValue;
}

void Cheltuiala::setType(const char* typeValue) {
    this->type = new char[strlen(typeValue) + 1];
    strcpy_s(this->type, strlen(typeValue) + 1, typeValue);
}

Cheltuiala &Cheltuiala::operator=(const Cheltuiala &c) {
    this->sum = c.sum;
    this->day = c.day;
    this->type = new char[strlen(c.type) + 1];
    strcpy(this->type, c.type);
    return *this;
}

bool Cheltuiala::operator==(const Cheltuiala &c1) {
    if(strcmp(this->type, c1.type) == 0)
        if(this->day == c1.day)
            if(this->sum == c1.sum)
                return true;
    return false;
}

ostream& operator<<(ostream& os, Cheltuiala& c) {
    os <<"Ziua "<<c.day<<";"<<"Suma "<<c.sum<<";"<<"Tipul "<<c.type<<endl;
    return os;
}







