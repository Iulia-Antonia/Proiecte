
#ifndef LAB78_TESTS_H
#define LAB78_TESTS_H
void testAll();
#endif //LAB78_TESTS_H
