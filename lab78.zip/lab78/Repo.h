//
// Created by Denisa on 4/8/2022.
//

#ifndef LAB78_REPO_H
#define LAB78_REPO_H

#include "Cheltuiala.h"

using namespace std;
class Repo {
private:
    Cheltuiala* cheltuieli;
    int dim;

public:
    Repo();
    Repo(int dim);
    Repo(const Repo& r);
    ~Repo();
    void add(Cheltuiala& c);
    void update(Cheltuiala& odlC, Cheltuiala& newC);
    void del(const Cheltuiala& c);
    int getSize();
    int findElem(const Cheltuiala& c);
    Cheltuiala* getAll();
    Repo& operator=(Repo & r);
    bool operator==(Repo &r1);
    friend ostream& operator<<(ostream& os, Repo& r);

};


#endif //LAB78_REPO_H
