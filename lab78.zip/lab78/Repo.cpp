//
// Created by Denisa on 4/8/2022.
//

#include "Repo.h"
#include "Cheltuiala.h"
#include <algorithm>
#include <iostream>
#include <cstring>

using namespace std;

Repo::Repo() {
    this->cheltuieli = nullptr;
    this->dim = 0;
}


Repo::Repo(int dim) {

    this->dim = dim;
    this->cheltuieli = new Cheltuiala[dim];

}

Repo::Repo(const Repo &r) {

    this->dim = r.dim;
    if(r.cheltuieli != nullptr) {
        this->cheltuieli = new Cheltuiala[dim];
        for (int i = 0; i < dim; i++)
            this->cheltuieli[i] = r.cheltuieli[i];
    }
    else this->cheltuieli = nullptr;

}


Repo::~Repo() {
    if(this->cheltuieli){
        delete[] this->cheltuieli;
        this->cheltuieli = nullptr;
    }
}

int Repo::getSize() {
    return this->dim;
}


Cheltuiala* Repo::getAll() {
    return this->cheltuieli;
}


int Repo::findElem(const Cheltuiala& c) {
    for(int i = 0; i < this->dim; i++)
        if(this->cheltuieli[i] == c)
            return i;
    return -1;
}

void Repo::add(Cheltuiala& c) {
    if(this->cheltuieli == nullptr){
        this->cheltuieli = new Cheltuiala;
        this->dim = 1;
        *this->cheltuieli = c;
    }
    else
    {Cheltuiala* newCheltuieli = new Cheltuiala[this->dim + 1];

    for(int i = 0; i < this->dim; i++)
        newCheltuieli[i] = this->cheltuieli[i];

    delete[] this->cheltuieli;
    this->cheltuieli = newCheltuieli;
    this->dim++;
    this->cheltuieli[this->dim - 1] = c;
    }
}

void Repo::update(Cheltuiala &odlC, Cheltuiala &newC) {
    int i = 0;
    bool ok = false;
    while(i < this->dim && !ok){
        if(this->cheltuieli[i] == odlC){
            this->cheltuieli[i] = newC;
            ok = true;
        }
        i++;
    }


}

void Repo::del(const Cheltuiala &c) {

    int poz = findElem(c);
    Cheltuiala* newVector = new Cheltuiala[this->dim - 1];

    for(int i = 0; i < this->dim; i++)
        if(i != poz)
            newVector[i] = this->cheltuieli[i];

    delete[] this->cheltuieli;
    this->cheltuieli = newVector;
    this->dim = dim - 1;
}

Repo &Repo::operator=(Repo &r) {
    delete[] this->cheltuieli;
    this->cheltuieli = new Cheltuiala[r.dim];
    this->dim = r.dim;
    for(int i = 0; i < r.dim; i++)
    {
        this->cheltuieli[i].setType(r.cheltuieli[i].getType());
        this->cheltuieli[i].setSum(r.cheltuieli[i].getSum());
        this->cheltuieli[i].setDay(r.cheltuieli[i].getDay());
    }
    return *this;
}

bool Repo::operator==(Repo &r1) {

    for(int i = 0; i < r1.dim; i++) {
        if (strcmp(this->cheltuieli[i].getType(), r1.cheltuieli[i].getType()) != 0) return false;
        if(this->cheltuieli[i].getDay() != r1.cheltuieli[i].getDay()) return false;
        if(this->cheltuieli[i].getSum() != r1.cheltuieli[i].getSum()) return false;
    }
    return true;
}

ostream &operator<<(ostream &os, Repo &r) {
    for(int i = 0; i < r.dim; i++)
        os <<"Ziua "<<r.cheltuieli[i].getDay()<<";"<<"Suma "<<r.cheltuieli[i].getSum()<<";"<<"Tipul "<<r.cheltuieli[i].getType()<<endl;

    return os;
}






/*

Repo::Repo(const char *fileName) {

    if(fileName != NULL) {
        this->fileName = new char[strlen(fileName) + 1];
        strcpy_s(this->fileName, strlen(fileName) + 1, fileName);
    }
    else
        this->fileName = NULL;

    this->loadFromFile();
}
*/

/*

void Repo::loadFromFile() {

    if(this->fileName)
    {
        ifstream f(this->fileName);
        int day, sum;
        char* type;
        while(!f.eof())
        {
            f>> day >> sum >> type;
            if(strlen(type) != 0) {
                Cheltuiala c(day, sum, type);
                this->add(c);
            }
        }
        f.close();
    }
}

void Repo::saveToFile() {

    if(this->fileName) {
        ofstream g(this->fileName);
        for (int i = 0; i < this->cheltuieli.size(); i++)
            g << this->cheltuieli[i] << endl;
    }
}
*/











