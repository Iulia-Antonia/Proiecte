#include "tests.h"
#include "Cheltuiala.h"
#include <cassert>
#include <cstring>
#include "Repo.h"
#include "Service.h"

void testConstructors(){
    Cheltuiala c;
    assert(c.getDay() == 1);
    assert(c.getSum() == 0);
    assert(strcmp(c.getType(), "") == 0);

    Cheltuiala c1(c);
    assert(c1.getDay() == 1);
    assert(c1.getSum() == 0);
    assert(strcmp(c1.getType(), "") == 0);
}

void testSetDay(){
    Cheltuiala c;
    c.setDay(10);
    assert(c.getDay() == 10);
}

void testSetSum(){
    Cheltuiala c;
    c.setSum(40.5);
    assert(c.getSum() == 40.5);
}

void testSetType(){
    Cheltuiala c;
    c.setType("transport");
    assert(strcmp(c.getType(), "transport") == 0);
}

void testGetDay(){
    Cheltuiala c(3, 15, "transport");
    assert(c.getDay() == 3);
}

void testGetSum(){
    Cheltuiala c(3, 15, "transport");
    assert(c.getSum() == 15);
}

void testGetType(){
    Cheltuiala c(3, 15, "transport");
    assert(strcmp(c.getType(), "transport") == 0);
}

void testConstructors2(){
    Repo r;
    Cheltuiala c1(1,14,"altele");
    Cheltuiala c2(30,140,"altele");
    assert(r.getSize() == 0);

    //copy constructor
    r.add(c1);
    r.add(c2);
    assert(r.getSize() == 2);
    Repo r2(r);
    assert(r2.getSize() == 2);


}

void testGetSizeRepo(){
    Repo r;
    Cheltuiala c1(1,2,"altele");
    r.add(c1);
    assert(r.getSize() == 1);
}

void testGetAllRepo(){
    Repo r;
    Cheltuiala c1(1,2,"altele");
    Cheltuiala c2(2,3,"altele");
    r.add(c1);
    r.add(c2);
    assert(r.getAll()[0] == c1);
    assert(r.getAll()[1] == c2);


}

void testAddRepo(){
    Repo r;
    Cheltuiala c(20,200,"transport");
    r.add(c);
    assert(r.getAll()[0] == c);
}

void testUpdateRepo(){
    Repo r;
    Cheltuiala cOld(10,15,"altele");
    Cheltuiala cNew(10,150,"altele");
    r.add(cOld);
    r.update(cOld, cNew);
    assert(r.getAll()[0].getSum() == 150);
}

void testDelRepo(){
    Repo r;
    Cheltuiala c1(12,30,"altele");
    Cheltuiala c2(15,45,"altele");
    Cheltuiala c3(12, 200," altele");
    r.add(c1);
    r.add(c2);
    r.add(c3);
    r.del(Cheltuiala(15,45,"altele"));
    assert(r.getSize() == 2);
}

void testConstructorsService(){
    Repo r;
    Service s(r);
    assert(s.getRepo().getSize() == 0);
}

void testAddService(){
    Repo r;
    Service s(r);
    s.addCheltuiala(10, 150, "altele");
    assert(s.getRepo().getSize() == 1);
}

void testDeleteService(){
    Repo r;
    Service s(r);
    s.addCheltuiala(10, 150, "altele");
    s.addCheltuiala(7, 550, "transport");
    assert(s.getRepo().getSize() == 2);
    s.deleteCheltuiala(10, 150, "altele");
    assert(s.getRepo().getSize() == 1);
    assert(s.getRepo().getAll()[0] == Cheltuiala(7, 550, "transport"));
}

void testUpdateService(){
    Repo r;
    Service s(r);
    s.addCheltuiala(10, 150, "altele");
    s.addCheltuiala(7, 550, "transport");
    s.updateCheltuiala(10, 150, "altele", 10, 200, "altele");
    assert(s.getRepo().getAll()[0].getSum() == 200);
}

void testCheltuiala(){
    testGetType();
    testGetSum();
    testGetDay();
    testSetType();
    testSetSum();
    testSetDay();
    testConstructors();
}

void testRepo(){
    testConstructors2();
    //testGetSizeRepo();
    testGetAllRepo();
    testAddRepo();
    testUpdateRepo();
    testDelRepo();
};

void testService(){
    testAddService();
    testDeleteService();
    testUpdateService();
    testConstructorsService();
}

void testAll() {
    testCheltuiala();
    testRepo();
    testService();
}