#include <iostream>
#include "Tests.h"
#include <iostream>
#include "Repo.h"

using namespace std;
int main() {

    testAll();
    Repo r;
    Cheltuiala c1(12, 500, "altele");
    Cheltuiala c2(7, 200, "transport");
    Cheltuiala c3(30, 120, "altele");
    r.add(c1);
    r.add(c2);
    r.add(c3);

    cout<<r<<endl<<endl;

    r.del(c2);
    cout<<r<<endl<<endl;

    r.update(c1, c3);

    cout<<r<<endl;
    cout<<"done";
    return 0;
}
