//
// Created by Denisa on 4/8/2022.
//

#ifndef LAB78_CHELTUIALA_H
#define LAB78_CHELTUIALA_H
#include <iostream>

using namespace std;

class Cheltuiala {
private:
    int day;
    float sum;
    char* type;
public:
    Cheltuiala();
    Cheltuiala(int day, float sum, const char* type);
    Cheltuiala(const Cheltuiala &c);
    ~Cheltuiala();
    int getDay();
    float getSum();
    char* getType();

    void setDay(int day);
    void setSum(float sum);
    void setType(const char* type);
    Cheltuiala& operator=(const Cheltuiala& c);
    bool operator==(const Cheltuiala &c1);
    friend ostream& operator<<(ostream& os, Cheltuiala& c);

};

#endif //LAB78_CHELTUIALA_H
